/* Blob の作成元は描画回ごとに作り、図は親が使い切りの内側へ直接渡す。 */
(function () {
  "use strict";
  if (parent !== window || opener) return;
  let provider = null;
  let serial = 0;
  let controller = null;
  const state = { done: true, results: [], active: 0, maxActive: 0, created: 0, disposed: 0 };
  window.__poc = state;

  function exchange(source, type, id, send, signal) {
    return new Promise((resolve, reject) => {
      function cleanup() {
        clearTimeout(timer);
        removeEventListener("message", receive);
        signal.removeEventListener("abort", abort);
      }
      function abort() { cleanup(); reject(new Error("中止")); }
      function receive(event) {
        if (event.source !== source() || event.origin !== "null" || event.data?.type !== type ||
            (id !== null && event.data.id !== id)) return;
        cleanup();
        resolve(event);
      }
      const timer = setTimeout(() => { cleanup(); reject(new Error("時間切れ")); }, 20000);
      addEventListener("message", receive);
      signal.addEventListener("abort", abort, { once: true });
      if (signal.aborted) abort();
      else {
        try { send(); }
        catch (error) { cleanup(); reject(error); }
      }
    });
  }

  function renderOverPort(port, source, theme, signal) {
    return new Promise((resolve, reject) => {
      function finish(callback, value) {
        clearTimeout(timer);
        signal.removeEventListener("abort", abort);
        port.close();
        callback(value);
      }
      function abort() { finish(reject, new Error("中止")); }
      const timer = setTimeout(() => finish(reject, new Error("時間切れ")), 20000);
      signal.addEventListener("abort", abort, { once: true });
      if (signal.aborted) { abort(); return; }
      port.onmessage = (event) => {
        if (event.data?.type === "result") finish(resolve, event.data);
      };
      try { port.postMessage({ type: "render", source, theme }); }
      catch (error) { finish(reject, error); }
    });
  }

  function discardProvider() {
    provider?.remove();
    provider = null;
    if (state.active) {
      state.active = 0;
      state.disposed++;
    }
  }
  state.cancel = () => {
    if (!controller) return;
    controller.abort();
    controller = null;
    discardProvider();
    state.done = true;
  };

  async function renderer(source, theme, signal) {
    if (!provider) {
      provider = document.createElement("iframe");
      provider.name = "fig-provider";
      provider.className = "fig-frame";
      provider.sandbox = "allow-scripts";
      provider.referrerPolicy = "no-referrer";
      provider.src = "blob-provider.html";
      await exchange(() => provider.contentWindow, "provider-ready", 0,
        () => document.body.appendChild(provider), signal);
      signal.throwIfAborted();
    }
    const owner = provider.contentWindow;
    const id = ++serial;
    state.created++;
    state.active = 1;
    state.maxActive = 1;
    const opened = await exchange(() => owner, "renderer-opened", id, () => owner.postMessage({ type: "open-renderer", id }, "*"), signal);
    if (opened.ports.length !== 1 || owner.length !== 1) {
      opened.ports.forEach((port) => port.close());
      throw new Error("描画枠または通信ポートの数が不正");
    }
    const result = await renderOverPort(opened.ports[0], source, theme, signal);
    await exchange(() => owner, "renderer-closed", id, () => owner.postMessage({ type: "close-renderer", id }, "*"), signal);
    signal.throwIfAborted();
    if (owner.length !== 0) throw new Error("描画枠が残っている");
    state.active = 0;
    state.disposed++;
    return result;
  }

  state.start = (sources, { dark = false } = {}) => {
    state.cancel();
    const run = new AbortController();
    controller = run;
    const signal = run.signal;
    state.done = false;
    state.results = [];
    document.querySelectorAll("img.fig-img").forEach((image) => image.remove());
    document.documentElement.dataset.theme = dark ? "dark" : "light";
    const theme = {
      background: dark ? "#171717" : "#ffffff", primaryColor: dark ? "#243a5e" : "#e8f0fc",
      primaryTextColor: dark ? "#ffffff" : "#242424", primaryBorderColor: dark ? "#92b6f5" : "#235a9f",
      lineColor: dark ? "#dddddd" : "#333333", fontFamily: '"Yu Gothic", "Meiryo", sans-serif',
    };
    void (async () => {
      try {
        for (const source of sources) {
          const result = await renderer(source, theme, signal);
          signal.throwIfAborted();
          const { w, h, svg } = result;
          if (result.ok !== true || typeof svg !== "string" || svg.length > 2000000 ||
              ![w, h].every((value) => Number.isFinite(value) && value > 0 && value <= 20000)) {
            state.results.push({ ok: false, error: "図を描けない" });
            continue;
          }
          const image = document.createElement("img");
          image.className = "fig-img";
          image.alt = "図";
          image.width = Math.ceil(w);
          image.height = Math.ceil(h);
          image.src = "data:image/svg+xml;charset=utf-8," + encodeURIComponent(svg);
          state.results.push({ ok: true, w, h, svg });
          document.getElementById("_body").appendChild(image);
        }
      } catch (error) {
        if (controller === run) {
          state.results.push({ ok: false, error: String(error.message) });
        }
      } finally {
        if (controller === run) {
          discardProvider();
          controller = null;
          state.done = true;
        }
      }
    })();
  };
  addEventListener("pagehide", () => {
    state.cancel();
    discardProvider();
  }, { once: true });
  if (!/[?&]manual=1(?:&|$)/.test(location.search)) {
    state.start(Array.from(document.querySelectorAll("code.language-mermaid"), (code) => code.textContent));
  }
})();
