/* 図ごとに二重枠を使い切る親。style 属性とインライン script は使わない。 */
(function () {
  "use strict";
  var current = null;
  var serial = 0;
  var state = { done: true, results: [], active: 0, maxActive: 0, created: 0, disposed: 0, runs: [] };
  window.__poc = state;
  function palette(dark) {
    return { background: dark ? "#171717" : "#ffffff", primaryColor: dark ? "#243a5e" : "#e8f0fc",
      primaryTextColor: dark ? "#ffffff" : "#242424", primaryBorderColor: dark ? "#92b6f5" : "#235a9f",
      lineColor: dark ? "#dddddd" : "#333333", fontFamily: '"Yu Gothic", "Meiryo", sans-serif' };
  }
  state.cancel = function () {
    if (!current) return;
    current.cancelled = true;
    current.jobs.slice().forEach(function (j) { j.dispose(); });
    current = null;
    state.done = true;
  };
  state.start = function (sources, opts) {
    state.cancel();
    document.querySelectorAll("img.fig-img").forEach(function (i) { i.remove(); });
    opts = opts || {};
    document.documentElement.setAttribute("data-theme", opts.dark ? "dark" : "light");
    var run = { id: ++serial, jobs: [], next: 0, complete: 0, cancelled: false };
    current = run;
    state.results = [];
    state.done = sources.length === 0;
    state.runs.push(run.id);
    var colors = palette(opts.dark);
    function pump() {
      if (run.cancelled || current !== run) return;
      // 複数の侵害された内側は、WindowProxy 経由で直接通信できる。
      // 次の図は前の組を破棄してから始め、同じページに 2 組を生かさない。
      if (run.next < sources.length && run.jobs.length === 0) launch(run.next++);
    }
    function launch(index) {
      var frame = document.createElement("iframe");
      frame.className = "fig-frame";
      frame.name = "fig-relay-" + run.id + "-" + index;
      frame.setAttribute("sandbox", "allow-scripts");
      frame.setAttribute("referrerpolicy", "no-referrer");
      frame.width = 1200;
      frame.height = 800;
      frame.src = opts.probe ? "probe-frame.html" : "frame.html";
      var phase = "loading";
      var job = { dispose: dispose };
      var timer = setTimeout(function () { finish({ ok: false, error: "時間切れ" }); }, opts.timeout || 20000);
      function dispose() {
        if (phase === "done") return;
        phase = "done";
        clearTimeout(timer);
        window.removeEventListener("message", receive);
        frame.remove();
        run.jobs.splice(run.jobs.indexOf(job), 1);
        state.active -= 1;
        state.disposed += 1;
      }
      function finish(result) {
        if (phase === "done" || run.cancelled || current !== run) return;
        var imageSource;
        if (result.ok && result.svg) {
          try { imageSource = "data:image/svg+xml;charset=utf-8," + encodeURIComponent(result.svg); }
          catch (_) { result = { ok: false, error: "図の文字が不正" }; }
        }
        dispose();
        result.index = index;
        result.run = run.id;
        state.results.push(result);
        if (result.ok && result.svg) {
          var img = document.createElement("img");
          img.className = "fig-img";
          img.alt = "図";
          img.width = Math.ceil(result.w);
          img.height = Math.ceil(result.h);
          img.src = imageSource;
          document.getElementById("_body").appendChild(img);
        }
        run.complete += 1;
        if (run.complete === sources.length) state.done = true;
        else pump();
      }
      function receive(e) {
        if (e.source !== frame.contentWindow || phase === "done" || run.cancelled) return;
        var d = e.data;
        if (!d || typeof d !== "object") return;
        if (d.type === "ready" && phase === "loading") {
          phase = "working";
          // URL、親の情報、別の図、ページ名は渡さない。
          frame.contentWindow.postMessage({ type: "render", source: sources[index], theme: colors }, "*");
        } else if (d.type === "result" && phase === "working") {
          if (opts.probe && typeof d.report === "string" && d.report.length <= 65536) {
            try { finish({ ok: true, report: JSON.parse(d.report) }); }
            catch (_) { finish({ ok: false, error: "検査結果を読めない" }); }
          } else if (!opts.probe && d.ok === true && typeof d.svg === "string" && d.svg.length <= 2000000 &&
                     Number.isFinite(d.w) && Number.isFinite(d.h) && d.w > 0 && d.h > 0 && d.w <= 20000 && d.h <= 20000) {
            finish({ ok: true, svg: d.svg, w: d.w, h: d.h });
          } else finish({ ok: false, error: "図を描けない" });
        }
      }
      run.jobs.push(job);
      state.active += 1;
      state.created += 1;
      state.maxActive = Math.max(state.maxActive, state.active);
      window.addEventListener("message", receive);
      document.body.appendChild(frame);
    }
    pump();
  };
  if (!/[?&]manual=1(?:&|$)/.test(location.search)) {
    state.start(Array.from(document.querySelectorAll("code.language-mermaid"), function (c) { return c.textContent; }));
  }
})();
